---
name: repo-teacher
description: Build teaching materials for an AI/ML-tooling seminar course, where each lesson covers one open-source tool/repo in depth. Use whenever the user wants to create a lecture deck, a pre/post comprehension quiz, and/or a hands-on practice assignment for a specific GitHub repo or AI tool — phrases like "make a lecture on [repo]", "teach [tool]", "quiz for [lesson]", "assignment for [repo]", or references to the repo-teacher project structure should all trigger this skill. Also use when updating/extending an existing lecture in this series (e.g. "add a slide", "fix the icons", "add a callback tag"), or when the user reports that a hands-on exercise didn't work as expected on the real tool. Produces three deliverables together — a .pptx lecture deck, a quiz.py comprehension check, and an assignment.md practice worksheet.
---

# Repo Teacher

A course-building skill for a recurring format: each lesson teaches one open-source AI/ML tool by pairing standalone conceptual background with a deep dive into that tool's actual repository. Every lesson produces up to three artifacts — a slide deck, a quiz, and a hands-on assignment — stored together in one directory per tool.

This skill encodes a design system and a set of hard-won lessons from building this format live. Read the relevant reference file(s) before generating any of the three artifacts — don't rely on memory of "what a lecture/quiz/assignment generally looks like."

## Directory convention

```
/Projects/repo-teacher/
├── lecture-1-foundations/
│   ├── AI_Tooling_Lecture1_Foundations.pptx
│   └── quiz.py
├── <tool-name>/
│   ├── <Tool>_Lecture.pptx
│   ├── quiz.py
│   └── <tool>_assignment.md
```

`quiz.py` writes its results to `quiz_history.json` in its own directory (path-relative via `__file__`), so each tool's quiz history stays local to that tool's folder.

## The course structure this serves

**Lecture 1 (Foundations)** is the only lesson that teaches general background — transformer architecture, training paradigms, the interpretability mindset, core vocabulary (residual stream, features, superposition, circuits, activation patching, SAEs, control vectors, logit lens). Every later lesson assumes this and never re-derives it.

**Every subsequent lesson** (one per tool) follows the same pattern: a little bit of tool-*specific* background that Lecture 1 didn't cover, then the tool itself. Read `references/lecture-structure.md` before building a deck — the standalone-background / explicit-bridge structure is the most important and most easily-lost part of this format.

## Before building anything: read the repo

For a tool-specific lesson, don't write slide content, quiz questions, or assignment exercises from a README skim alone. Actually fetch and read:
- The README (setup instructions, recommended configs — reuse exact values, don't paraphrase URLs/model names/flags)
- The core source file(s) implementing the main algorithm (for real function names, real data structures, real control-flow — cite these exactly in the deck)
- The actual GitHub file listing, in its real order (for the repository-structure slide — see `references/lecture-structure.md`)
- Open issues, if any (useful for the limitations slide, and for knowing if a known bug is already tracked)

If the tool depends on a third-party API whose behavior matters (rate limits, which models support which features, endpoint shapes), verify current behavior — don't assume docs read weeks/months ago are still accurate. Provider APIs drift; tools built against them can silently break. This isn't optional color, it's the single most common source of errors in this project so far (see the validation section below).

## The three artifacts

Read the matching reference file before building each one:

- **Lecture deck** → `references/lecture-structure.md` (slide flow, design system, the icon-contrast bug, back-reference tags)
- **Quiz** → `references/quiz-structure.md` (question types, scoring rules, file structure — this one includes a working code template)
- **Assignment** → `references/assignment-structure.md` (exercise format, and the mandatory validation step)

## The most important lesson learned so far

The first assignment draft in this series contained a real, substantive bug: exercises told the user to type sentence-fragment prompts like `2 + 2 =` and `My favorite color is` directly into a **chat-mode** prompt box, on the unstated assumption that a chat model would complete the fragment the way a base model does. It doesn't — a chat-mode prompt box is a user message, and the model responds to it rather than continuing it. This was caught by the user testing the assignment live, not by anything in the drafting process.

**The fix, now load-bearing for every assignment in this skill:** before finalizing any exercise that prescribes a specific prompt or setting, trace the assumption to how the tool's *actual* request-building code handles it (read the source, not just the README's description), or — better — run the exercise once against the live tool yourself if you have the means to. Treat "I reasoned about how this API should behave" as insufficient justification for a published exercise on its own. `references/assignment-structure.md` has the full checklist.

## Iterating on an existing lesson

If the user reports something's wrong with an already-built deck/quiz/assignment (a broken exercise, a factual error, an icon that's hard to see, a slide that needs restructuring), fix it directly in place rather than rebuilding from scratch — these are long, hand-tuned files and a full rebuild risks losing unrelated fixes made in earlier passes. Re-render and visually inspect any slide you touch (see the QA step in `references/lecture-structure.md`) before considering the fix done.
